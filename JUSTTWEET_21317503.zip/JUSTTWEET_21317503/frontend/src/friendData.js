import profile2 from "./images/profile2.jpg";
import profile3 from "./images/profile3.jpg";
import profile4 from "./images/profile4.jpg";

const friendData = [
  {
    id: 1,
    name: "Elon Musk",
    image: profile2,
    email: "elonmusk@tesla.com"
  },
  {
    id: 2,
    name: "Harry Potter",
    image: profile3,
    email: "harrypotter@castle.com"
  },
  {
    id: 3,
    name: "Priyanka Chopra",
    image: profile4,
    email: "pc@india.com"
  }
];

export default friendData;

